exports.handler = async (event) => {
  return 'Hello form Lambda!'
};
